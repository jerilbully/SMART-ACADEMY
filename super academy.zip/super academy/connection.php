<?php
$conn = mysqli_connect("localhost","root","","super_academy");

// if($conn)
// {
// 	echo "Connection Successful hvjhvjhv";
// }
// else
// {
// 	echo "Connection not Successful";
// }
?>

